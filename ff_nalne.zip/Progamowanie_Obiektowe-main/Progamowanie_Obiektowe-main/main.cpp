#include <iostream>
#include <vector>
#include "mikrofala.h"
#include "potrawa.h"
#include "main.h"

#include <string>
#include <conio.h>
#include <fstream>

using namespace std;


int main()
{
    Mikrofala mikrofala;
    vector <Potrawa> surowePotrawy;
    vector <GotowaPotrawa> przygotowanePotrawy;
    vector <SpalonaPotrawa> spalonePotrawy;
    SpalonaPotrawa JakasPotrawa;
    GotowaPotrawa JakasPotrawa2;
    bool isRunning = 1;

    Czytanie_z_pliku(surowePotrawy);
    do
    {
        Wyswietl_Menu(surowePotrawy);

        if (spalonePotrawy.empty()){cout<<"Brak spalonych potraw!"<<endl;}
        else{Wyswietl_Spalone(spalonePotrawy);}

        if (przygotowanePotrawy.empty()){cout<<"Brak przygotowanych potraw!"<<endl;}
        else{Wyswietl_Gotowe(przygotowanePotrawy);}

        mikrofala.Ustaw(Wybierz_Potrawe(surowePotrawy), spalonePotrawy, przygotowanePotrawy);
        ProgramStop( przygotowanePotrawy, spalonePotrawy);

    }while(isRunning == 1);

    return(0);
}
