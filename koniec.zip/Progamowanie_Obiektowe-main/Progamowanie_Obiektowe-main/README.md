# Progamowanie_Obiektowe!

Projekt na zajęcia z programowania obiektowego projekt nr 1. 
Program „Kuchenka mikrofalowa” Program ma symulować działanie kuchenki mikrofalowej. Kuchenka mikrofalowa ma umożliwiać „gotowanie” potraw po uprzednim ustawieniu temperatury oraz czasu działania urządzenia. Program ma być skonstruowany w taki sposób, aby możliwa była sytuacja w której dana potrawa „spali się” w sytuacji gdy czas „gotowania” nie odpowiada rodzajowi „gotowanego” produktu.