#include <iostream>
#include <vector>
#include "mikrofala.h"
#include "potrawa.h"
#include "main.h"

#include <string>
#include <conio.h>
#include <fstream>

using namespace std;

void Wyswietl_Menu( vector <Potrawa> &menu)
{
    for(int i =0; i<menu.size() ; i++)
    {
        cout<<"Numer w menu: "<<menu[i].getId()<<endl;
        cout<<"Nazwa potrawy: " << menu[i].getNazwa()<<endl;
        cout<<"Ilosc: "<<menu[i].ilosc<<endl;
    }
}


int main()
{
    Mikrofala mikrofala;
    Potrawa spaghetti;

    spaghetti.UstawPotrawe(0,"Spaghetti",15,40,1);

    vector <Potrawa> menu;
    Czytanie_z_pliku(menu);

    Wyswietl_Menu(menu);

    
    /*cout << "ID: " << spaghetti.getId();
    cout << "Nazwa: " << spaghetti.getNazwa();*/ //Funkcje testowe

    return(0);
}

