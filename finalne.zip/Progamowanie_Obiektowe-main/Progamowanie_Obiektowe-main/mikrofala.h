#ifndef MIKROFALA_H
#define MIKROFALA_H

#include <iostream>
#include <vector>
#include <string>
#include <conio.h>
#include <fstream>

#include "main.h"
#include "potrawa.h"

class Mikrofala
{
public:
  
    void Ustaw(Potrawa aObiekt, std::vector <SpalonaPotrawa> &aMenuSpalonych, std::vector <GotowaPotrawa> &aMenuPrzygotowanych);
   
};

#endif //MIKROFALA_H
